#ifndef __TP2LIB_H__
#define __TP2LIB_H__
#include "stm32f10x.h"

void InitialiserTIM2 (void);
void DemarrerTIM2(void);
void InitialiserTIM3 (void);
void DemarrerTIM3(void);
void TempoCPU(void);
#endif
