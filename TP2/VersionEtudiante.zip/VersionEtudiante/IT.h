#ifndef __IT_H__
#define __IT_H__
#include "stm32f10x.h"

int timerInitIT (TIM_TypeDef * timer, int priority);

#endif
